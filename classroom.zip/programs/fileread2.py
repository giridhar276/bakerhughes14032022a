
import csv
with open("languages.txt","r") as fobj:
    # convert fobj to csv obj( csv understanble format)
    reader = csv.reader(fobj, delimiter = "," )
    for line in reader:
        print(line)





    
