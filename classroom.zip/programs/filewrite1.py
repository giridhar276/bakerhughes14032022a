# opening the file in write mode
fobj = open("languages.txt","w")
# operation
fobj.write("python programming\n")
fobj.write("spark\n")
fobj.close()

fw = open("numbers.txt","w")
for val in range(1,10):
    fw.write(str(val) + "\n")
fw.close()

#fw = open(r"D:\new\new\numbers.txt","w")  # raw string
#fw = open("D:/new/new/numbers.txt","w")
fw = open("D:\\new\\new\\numbers.txt","w")
for val in range(1,10):
    fw.write(str(val) + "\n")
fw.close()