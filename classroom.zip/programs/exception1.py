

import csv
citylist = []
#citylist = ()
try:
    filename = input("Enter any filename :")
    with open(filename,"r") as fobj:
        reader= csv.reader(fobj)
        for line in reader:
            city = line[1]
            citylist.append(city)
            
    #output = "hello" + 9
    #print(output)
except Exception as error:
    print("user defined error:","File not found..pl check")
    print(error)    
else:       
        # display
        for city in set(citylist):
            print(city)
        print()
        print("No. of cities :", len(set(citylist)))    
finally:
    print("End of file processing")        