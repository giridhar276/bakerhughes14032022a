

#5. Write a Python program to read realestate.csv and replace all the lines containing SACRAMENTO with HYDERABAD and and write the output to processeddata.csv
with open("realestate.csv","r") as fobj:
    with open("processed.csv","w") as fw:
        for line in fobj:
            line = line.replace('SACRAMENTO','HYDERABAD').strip()
            fw.write(line + "\n")
            
            
import csv        
with open("realestate.csv","r") as fobj:
    reader = csv.reader(fobj)
    with open("processed.csv","w") as fw:
        for line in reader:
                if "SACRAMENTO" in line:
                    line[1] = 'HYDERABAD'
                #converting list to string
                output = ",".join(line)
                fw.write(output + "\n")
                


import csv            
with open("realestate.csv","r") as fobj:
    reader = csv.reader(fobj)
    with open("processed1.csv","w") as fw:
        writer = csv.writer(fw)
        for line in reader:
                if "SACRAMENTO" in line:
                    line[1] = 'HYDERABAD'
                writer.writerow(line)              