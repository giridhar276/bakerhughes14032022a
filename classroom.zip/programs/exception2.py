

import csv
citylist = []
#citylist = ()
try:
    filename = input("Enter any filename :")
    with open(filename,"r") as fobj:
        reader= csv.reader(fobj)
        for line in reader:
            city = line[1]
            citylist.append(city)
            
    output = "hello" + str(9)
    print(output)
    
    alist = [10,20]
    print(alist[100])
    
except FileNotFoundError as err:
    print("user defined error:","File not found..pl check")
    print(err)    
except TypeError as err:
    print(err)    
except (IndexError,KeyError) as err:
    print("Index or key is not found")
    print(err)
except Exception as error:
    print(error)    
else:       
        # display
        for city in set(citylist):
            print(city)
        print()
        print("No. of cities :", len(set(citylist)))    
finally:
    print("End of file processing")        