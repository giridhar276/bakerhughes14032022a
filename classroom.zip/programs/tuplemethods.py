
# list of lists
#[["Ram",30,"M"],["Rita",30,"F"]]

# list of tuples
#[("Ram",30,"M"),("Rita",30,"F")]


alist = [10,30,40,40]
alist[0] = 100
print('After replacing :', alist)


atup = (45,34,32)
atup[0] = 10   #-- comment this line
print("After replacing :",atup)


#typecasting - converting from one object to another object
alist = list(atup)
#making some changes
alist.append(44)
# reconverting back
atup = tuple(alist)

print("After replacing:", atup)


# string is immutable
string = "python"
string[0] = "z"  ##-- comment this line
print(string)
