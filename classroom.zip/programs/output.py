


name = "python programming"
print("I love",name)

print(10,20,30,40)

print("python","oracle")

