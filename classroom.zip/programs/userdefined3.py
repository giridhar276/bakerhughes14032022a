

#keyword parameters
def display(c,a,b):
    print(a,b,c)
display(10,20,30)



def display(c,a,b):
    print(a,b,c)
display(a=10,b=20,c=30)




print(10,10,sep= " ", ending = "\n")
print(10,10, end = "\n",sep= " ")