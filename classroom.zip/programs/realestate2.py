'''
Write a Python program to read realestate.csv and display the count of an individual city.

SACRAMENTO  - 34 times
RIO LINDA   - 30 times
'''

import csv
citylist = []
#citylist = ()
with open("realestate.csv","r") as fobj:
    reader= csv.reader(fobj)
    # processing
    for line in reader:
        city = line[1]
        citylist.append(city)
    #print(citylist)
        # display
    for city in set(citylist):
        print(city.ljust(20), citylist.count(city),"times")
    print()
    print("No. of cities :", len(set(citylist)))