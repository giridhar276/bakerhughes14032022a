import csv

with open("languages.txt","r") as fobj:
    pass   
