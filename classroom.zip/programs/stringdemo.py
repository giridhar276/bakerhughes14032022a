name = "python programming"
print("I love",name)
print( 10 ,20,30,40)
print("python","oracle")
name = "python programming"
print(name.capitalize())
print(name.upper())
print(name.lower())
print(name.replace("python","ruby"))
print(name)
print(name.count("p")) # 2
print(name.islower())
print(name.isupper())
print(name.startswith("p"))
print(name.startswith("q"))
print(name.endswith("g"))
print(name.find("tho"))  # if existing then return the starting index
print(name.find("we"))   # if not existing return -1
aname = " python "
print(len(aname))
print(len(aname.strip()))   # remove whitespace
print(len(aname.rstrip()))
print(len(aname.lstrip()))

bname = "I love {} and {}"   #template  #placeholder
print(bname.format("python","hadoop"))
print(bname.format(1,2))
print(bname.format("python","unix"))

bname = "I love {0} and {1}"   #template  #placeholder
print(bname.format("python","hadoop"))
print(bname.format(1,2))
print(bname.format("python","unix"))

bname = "I love {1} and {0}"   #template  #placeholder
print(bname.format("python","hadoop"))


bname = "I love {1} and {0}"   #template  #placeholder
print(bname.format([10,20],[40,50]))





name = "python programming"
if name.isupper():
    print("string is defined in uppercase")
    print("Inside if cond")
    print("Still inside if cond")
else:
    print("string is defined in lower")
    print("inside else part")
    print("Still inside else")



if name.isupper():
    print("String is deifned in upper")
    if len(name) > 10 :
        print("String length is greater than 10 ")
        print("Inside nested if")
    else:
        print("String length is less than 10")
        print("inside nested else")
else:
    print("String is defined in lower")


# range(start,stop,incremental)
# for loop for displaying numbers from 1 to 10
for val in range(1,11):     #range(1,11,1)    # both are same
    print(val)

# for loop for iterating the string   
name = "python"
for char in name:
    print(char)


for val in range(10,0,-1):
    print(val)


# strig slicing
# string[start:stop:step]
name = "python programming"
print(name[0])
print(name[1])
print(name[0:5])
print(name[3:8])
print(name[::])
print(name[:])
print(name[0:18:2])
print(name[1:18:2])
print(name[::4])
print(name[-1])
print(name[-2])
print(name[-5:-3])
print(name[::-1])    # reverse of the string


for val in name[::-1]:
    print(val)















































