

import os
try:
    for file in os.listdir():
        if os.path.isfile(file) and file.endswith(".py"):
            print(file.ljust(20) , os.path.getsize(file),"bytes")
except Exception as err:
    print(err)