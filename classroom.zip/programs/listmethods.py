alist = [10,20,5,43,56,3,78]

alist[2] = 20
print(alist)
# add single value at the end
alist.append(54)
print("After appending :", alist)
alist.append(87)
print("After appending :", alist)

# add multiple values at the end of the list
alist.extend([87,54,32])
print('After extending :', alist)

# list.insert(index,value)
alist.insert(1,100)
print('After inserting :', alist)

# list.insert(index,value)
alist.insert(5,1000)
print('After inserting :', alist)

#pop(index)    - pop()  is used if you know the index
alist.pop(4)  # value at index 4 will be removed
print('after pop:', alist)

#list.remove(value) - value in the list will be remove
alist.remove(56)
print('After remove :', alist)


if 56 in alist:
    alist.remove(56)
    print('After remove :', alist)
else:
    print(56,"doesn't exist in the list")

#list.reverse()  - in place
alist.reverse()
print("After reversing :", alist)

#list.sort() - ascending order
alist.sort()
print('after sorting - ascneding :',alist)
#list.sort() - descending order
alist.sort(reverse = True)
print('after sorting - descending :',alist)

















