

import csv
with open("realestate.csv","r") as fobj:
    # convert fobj to csv obj( csv understanble format)
    reader = csv.reader(fobj, delimiter = "," )
    for line in reader:
        print(line)