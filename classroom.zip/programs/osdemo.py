
import os
#print(os.listdir())
try:
    for file in os.listdir():
        print(file)

except Exception as err:
    print(err)        
