print("python","unix","spark")
print(10,20,30)
name = "python programming"
print("I love",name)
## string methods
print(name.capitalize())
print(name.upper())
print(name.title())
print(name.lower())
print(name.count("p")) #2
print(name.count("prog"))

print(name.find("h"))    #if existing... will return the index
print(name.find("z"))    # if not existing.. will return -1

print(name.isupper())
print(name.islower())
print(name.isalpha())
print(name.islower())

print(name.split(" "))

aname = " python  "
print(len(aname))  # 9
print(len(aname.strip()))
print(len(aname.rstrip()))
print(len(aname.lstrip()))

print(name.replace("python","ruby"))

name = "I love {} and {}"   # template    # which can be reused again and again
print(name.format("python","unix"))
print(name.format("hadoop","ML"))
#or
name = "I love {0} and {1}"   # template    # which can be reused again and again
print(name.format("python","unix"))
print(name.format("hadoop","ML"))

name = "I love {1} and {0}"   # template    # which can be reused again and again
print(name.format("python","unix"))
print(name.format("hadoop","ML"))


name = "python programming"
if name.isupper():
    print("String is upper")
    print("Inside if")
    print("Still inside if")
else:
    print("String is lower")
    print("inside else")
    print("Still inside else")



if name.startswith("p"):
    print("Its python programming")
else:
    print("Its unix shell scripting")



# range(start,stop,incremental)
for val in range(1,10,1):
    print(val)


# reverse order
for val in range(10,0,-1):
    print(val)
# even numbers
for val in range(2,10,2):
    print(val)

    
name = "python"
for char in name:
    print(char)



for val in range(10,-10,-1):
    print(val)


alist = [10,20,30]
for val in alist:
    print(val)




# slicing
#string[start:stop:incremental]
name = "python programming"
print(name[0])
print(name[1])
print(name[0:8])
print(name[3:9])
print(name[::])
print(name[:])
print(name[::1])
print(name[::2])
print(name[:4])
print(name[0:18:2])
print(name[1:18:2])
print(name[-1])
print(name[-2])
print(name[-5:-3])
print(name[::-1])



























    

    








    

    











      
