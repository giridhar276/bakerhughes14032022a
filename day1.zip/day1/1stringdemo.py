




print("python","unix","spark")

print(10,20,30)

name = "python programming"
print("I love",name)
